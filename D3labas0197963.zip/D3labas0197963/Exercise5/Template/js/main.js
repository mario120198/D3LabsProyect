/*
*    main.js
    Exercise5
*/

var svg = d3.select("#chart-area").append("svg")
	.attr("width", 600)
	.attr("height", 400)
    .attr("background", "black");
 
d3.json("data/buildings.json").then((data)=> {
        console.log(data);     
	});
	
var margin = svg.append("margin")
	.attr("top", 100)
	.attr("right", 10)
	.attr("bottom", 100)
	.attr("left", 10)
	 


var rect = svg.append("rect")
	.attr("x", 20)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 500)
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 50)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 385)
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 80)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 375)
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 110)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 375)
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 140)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 370)
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 170)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 345)
    .attr("fill","blue");
    
var rect = svg.append("rect")
	.attr("x", 200)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 340)
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 230)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 333)
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 260)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 333)
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 290)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 330)
    .attr("fill","blue");
