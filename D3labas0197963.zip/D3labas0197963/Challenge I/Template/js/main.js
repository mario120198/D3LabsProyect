/*
*    main.js
    Challenge
*/var svg = d3.select("#chart-area").append("svg")
	.attr("width", 330)
	.attr("height", 900)
	.attr("background", "red");

d3.json("data/buildings.json").then((data)=> {
    console.log(data);
    
});

var rect = svg.append("rect")
	.attr("x", 20)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 828)
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 50)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 632)
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 80)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 601)
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 110)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 599)
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 140)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 596.6)
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 170)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 554.5)
    .attr("fill","blue");
    
var rect = svg.append("rect")
	.attr("x", 200)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 541.3)
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 230)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 530)
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 260)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 530)
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 290)
	.attr("y", 20)
	.attr("width", 20)
    .attr("height", 528)
    .attr("fill","blue");
