/*
*    main.js
    Exercise3
*/

var svg = d3.select("#chart-area").append("svg")
	.attr("width", 500)
    .attr("height", 500)
    .attr("style", "black");

d3.csv("data/ages.csv").then((data)=> {
	console.log(data);
});

d3.json("data/ages.json").then((data)=> {

	data.forEach((d)=>{
		d.age = +d.age;
	});
	console.log(data);
});


var circle = svg.append("circle")
	.attr("cx", 25)
	.attr("cy", 150)
	.attr("r", 20)
    .attr("fill", "Blue");

var circle = svg.append("circle")
	.attr("cx", 75)
	.attr("cy", 150)
	.attr("r", 25)
    .attr("fill", "Blue");

var circle = svg.append("circle")
	.attr("cx", 125)
	.attr("cy", 150)
	.attr("r", 15)
    .attr("fill", "Blue");

var circle = svg.append("circle")
	.attr("cx", 175)
	.attr("cy", 150)
	.attr("r", 20)
    .attr("fill", "Blue");

var circle = svg.append("circle")
	.attr("cx", 225)
	.attr("cy", 150)
	.attr("r", 23)
    .attr("fill", "Blue");