/*
*    main.js
    Exercise2
*/

var svg = d3.select("#chart-area").append("svg")
	.attr("width", 400)
    .attr("height", 400);


var data = [25, 20, 15, 10, 5];

var rect = svg.append("rect")
	.attr("x", 10)
	.attr("y", 30)
	.attr("width", 40)
	.attr("height", data[0])
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 10)
	.attr("y", 60)
	.attr("width", 40)
	.attr("height", data[1])
    .attr("fill","red");

var rect = svg.append("rect")
	.attr("x", 10)
	.attr("y", 90)
	.attr("width", 40)
	.attr("height", data[2])
    .attr("fill","green");

var rect = svg.append("rect")
	.attr("x", 10)
	.attr("y", 120)
	.attr("width", 40)
	.attr("height", data[3])
    .attr("fill","blue");

var rect = svg.append("rect")
	.attr("x", 10)
	.attr("y", 150)
	.attr("width", 40)
	.attr("height", data[4])
    .attr("fill","red");

